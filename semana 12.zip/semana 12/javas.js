var dias_semana=["Lunes","Martes","Miercoles","Jueves","Viernes","Sabado","Domingo"]
var Dia=dias_semana[0]; //muestra lunes
console.log(Dia);Lunes